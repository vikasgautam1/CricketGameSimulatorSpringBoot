public interface Keeper {
    void keepWicket();
}
