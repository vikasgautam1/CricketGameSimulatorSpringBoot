public interface Player {
    void bat();
}
