public interface Bowler {
    void bowl();
}
