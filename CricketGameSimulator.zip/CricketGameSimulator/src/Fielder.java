public interface Fielder {
    void field();
}
